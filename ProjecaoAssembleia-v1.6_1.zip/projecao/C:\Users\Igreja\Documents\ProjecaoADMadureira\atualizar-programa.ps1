﻿$ErrorActionPreference = 'SilentlyContinue'
$log = 'C:\Users\Igreja\Documents\ProjecaoADMadureira\atualizacao.log'
function Anota($t) { Add-Content -LiteralPath $log -Value ('[' + (Get-Date -Format s) + '] ' + $t) -Encoding UTF8 }
Anota 'Ajudante de atualizacao comecou'
Wait-Process -Id 4242 -Timeout 90
Get-Process | Where-Object { $_.Path -eq 'C:\Program Files\Projeção Assembleia\Projeção Assembleia.exe' } | Stop-Process -Force
Start-Sleep -Milliseconds 1500
Anota 'Programa fechado; rodando o instalador'
$p = Start-Process -FilePath '/tmp/claude-0/t/inst.exe' -ArgumentList '/S','--updated','/allusers','/D=C:\Program Files\Projeção Assembleia' -Wait -PassThru
Anota ('Instalador terminou com codigo ' + $p.ExitCode)
$t = 0; while ((Get-Process -Name 'inst' -ErrorAction SilentlyContinue) -and $t -lt 300) { Start-Sleep -Seconds 1; $t++ }
$v = (Get-Item -LiteralPath 'C:\Program Files\Projeção Assembleia\Projeção Assembleia.exe').VersionInfo.ProductVersion
Anota ('Versao instalada agora: ' + $v)
Start-Sleep -Milliseconds 800
Start-Process -FilePath 'C:\Program Files\Projeção Assembleia\Projeção Assembleia.exe'