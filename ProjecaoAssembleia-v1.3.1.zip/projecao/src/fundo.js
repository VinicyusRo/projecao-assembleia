// Funções compartilhadas entre o telão, a prévia e as miniaturas
window.LOGO_PADRAO = '../assets/logo.png';

window.TEMAS = [
  { nome: 'Verde', css: 'linear-gradient(135deg,#0f3d2c,#1b4d3a 55%,#0b2a1e)', cor: '#0c241a', texto: '#ffffff' },
  { nome: 'Verde luz', css: 'radial-gradient(circle at 30% 20%,#2e7a58,#0f3123 70%)', cor: '#0f3123', texto: '#ffffff' },
  { nome: 'Dourado', css: 'radial-gradient(circle at 50% 115%,rgba(224,185,106,.55),transparent 60%),linear-gradient(#123828,#0c241a)', cor: '#0c241a', texto: '#ffffff' },
  { nome: 'Bege', css: 'linear-gradient(135deg,#f4f1ea,#e6d8b8)', cor: '#efe6d2', texto: '#1b4d3a' },
  { nome: 'Branco', css: 'linear-gradient(#ffffff,#f1ede3)', cor: '#ffffff', texto: '#14231b' },
  { nome: 'Noite', css: 'linear-gradient(160deg,#0b1630,#1d2f5a)', cor: '#0b1630', texto: '#ffffff' },
  { nome: 'Preto', css: null, cor: '#000000', texto: '#ffffff' }
];

const escH = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

window.aplicarFundo = function (el, c) {
  el.style.backgroundColor = c.fundoCor || '#000';
  if (c.fundoImg) el.style.backgroundImage = `url("${c.fundoImg}")`;
  else if (c.fundoCss) el.style.backgroundImage = c.fundoCss;
  else el.style.backgroundImage = 'none';
};

// Reduz a fonte até cada linha caber inteira; se ficar pequena demais, permite quebrar
window.ajustarFonte = function (el, caixa, max, fator = 0.88) {
  const cabe = () => el.scrollHeight <= caixa.clientHeight * fator && el.scrollWidth <= el.clientWidth + 1;
  el.style.whiteSpace = 'pre';
  let tam = max; el.style.fontSize = tam + 'px';
  while (tam > max * 0.55 && !cabe()) { tam -= 1; el.style.fontSize = tam + 'px'; }
  if (cabe()) return;
  el.style.whiteSpace = 'pre-line';
  tam = max; el.style.fontSize = tam + 'px';
  while (tam > 5 && !cabe()) { tam -= 1; el.style.fontSize = tam + 'px'; }
};

// Sombra só quando o texto é claro (em fundos claros a sombra escura borra a letra)
window.sombraTexto = function (cor) {
  const m = /^#?([0-9a-f]{6})$/i.exec(cor || '#ffffff');
  const n = m ? parseInt(m[1], 16) : 0xffffff;
  const lum = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  return lum > 0.5 ? '0 .04em .14em rgba(0,0,0,.9), 0 0 .3em rgba(0,0,0,.5)' : '0 0 .25em rgba(255,255,255,.6)';
};

// ---------- Aviso (cartaz) com fundo e estilo próprios ----------
window.AVISO_PADRAO = {
  titulo: 'Novo aviso', texto: '', fundoTipo: 'tema', fundoTema: 0, fundoCor: '#1b4d3a', fundoImg: null,
  escurecer: 0, corTitulo: '#ffffff', corTexto: '#f4f1ea', tamanho: 100, posicao: 'centro', destaque: true
};
window.fundoDoAviso = function (a) {
  if (a.fundoTipo === 'img' && a.fundoImg) return `#000 url('${String(a.fundoImg).replace(/'/g, '%27')}') center / cover no-repeat`;
  if (a.fundoTipo === 'cor') return a.fundoCor || '#000';
  const t = TEMAS[a.fundoTema || 0] || TEMAS[0];
  return t.css ? `${t.css}, ${t.cor}` : t.cor;
};
window.htmlAviso = function (aviso) {
  const a = Object.assign({}, AVISO_PADRAO, aviso);
  const k = (a.tamanho || 100) / 100;
  const pos = {
    centro: 'justify-content:center;align-items:center;text-align:center',
    baixo: 'justify-content:flex-end;align-items:center;text-align:center',
    topo: 'justify-content:flex-start;align-items:center;text-align:center',
    esquerda: 'justify-content:center;align-items:flex-start;text-align:left'
  }[a.posicao] || '';
  const sombra = a.fundoTipo === 'img' ? 'text-shadow:0 .08em .3em rgba(0,0,0,.6);' : '';
  const linha = a.destaque ? `<div style="width:9cqw;height:.55cqw;background:#E0B96A;border-radius:1cqw;margin:1.6cqw 0"></div>` : '<div style="height:1.4cqw"></div>';
  return `<div style="position:absolute;inset:0;container-type:size;overflow:hidden;font-family:'Segoe UI',system-ui,Arial,sans-serif">
    <div style="position:absolute;inset:0;background:${fundoDoAviso(a)}"></div>
    <div style="position:absolute;inset:0;background:rgba(0,0,0,${(a.escurecer || 0) / 100})"></div>
    <div style="position:absolute;inset:7cqh 7cqw;display:flex;flex-direction:column;${pos};${sombra}">
      <div style="font-weight:800;font-size:${(7 * k).toFixed(2)}cqw;line-height:1.05;color:${a.corTitulo};white-space:pre-line">${escH(a.titulo)}</div>
      ${a.texto ? linha + `<div style="font-weight:500;font-size:${(3.6 * k).toFixed(2)}cqw;line-height:1.3;color:${a.corTexto};white-space:pre-line;max-width:80cqw">${escH(a.texto)}</div>` : ''}
    </div></div>`;
};

// ---------- Painéis do rotativo: aniversariantes e visitantes ----------
// Cartões de tamanho fixo (sempre o mesmo, com 1 ou 4 pessoas), alinhados à esquerda.
const urlCss = u => `url('${String(u).replace(/'/g, '%27')}')`;
window.htmlPainel = function (p, logo, aSeguir) {
  const I = window.Igreja;
  const fonte = `'DM Sans','Segoe UI',system-ui,Arial,sans-serif`;
  const base = `position:absolute;inset:0;container-type:size;overflow:hidden;font-family:${fonte};color:#fff;background:#0f2a20`;
  const enfeites = `
    <div style="position:absolute;left:-9cqw;top:-16cqw;width:30cqw;height:30cqw;border-radius:50%;background:#16382b"></div>
    <div style="position:absolute;right:-12cqw;bottom:-22cqw;width:36cqw;height:36cqw;border-radius:50%;background:#14352a"></div>`;
  const topo = (olho, titulo, sub) => `
    <div style="position:absolute;left:4cqw;right:16cqw;top:4.5cqh">
      <div style="color:#E0B96A;font-weight:800;letter-spacing:.12em;font-size:1.5cqw;text-transform:uppercase">${escH(olho)}</div>
      <div style="font-weight:800;font-size:4.6cqw;line-height:1.05;margin-top:.6cqh;letter-spacing:-.02em">${escH(titulo)}</div>
      <div style="font-size:1.75cqw;font-weight:500;color:#d8e6dd;margin-top:.8cqh">${escH(sub)}</div>
    </div>
    <img src="${escH(logo || LOGO_PADRAO)}" style="position:absolute;top:4cqh;right:3.5cqw;width:6cqw;height:6cqw;object-fit:contain;background:#fff;border-radius:50%">`;
  const pagina = p.total > 1 ? `<div style="position:absolute;left:4cqw;bottom:4cqh;font-size:1.2cqw;color:#9fbfae;letter-spacing:.08em">${p.pagina} DE ${p.total}</div>` : '';
  const seguir = aSeguir ? `
    <div data-seguir style="position:absolute;right:2.5cqw;bottom:2.5cqw;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.14);border-radius:.8cqw;padding:1cqw 1.4cqw;max-width:30cqw">
      <div style="color:#E0B96A;font-weight:800;font-size:1.1cqw;letter-spacing:.1em" data-contagem>${aSeguir.segundos != null ? 'A SEGUIR • EM ' + String(aSeguir.segundos).padStart(2, '0') + 'S' : 'A SEGUIR'}</div>
      <div style="font-weight:700;font-size:1.6cqw;margin-top:.3cqw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escH(aSeguir.nome)}</div>
    </div>` : '';
  const selo = txt => `<span style="position:absolute;top:1cqw;left:1cqw;background:#E0B96A;color:#14231B;font-weight:800;font-size:1.15cqw;letter-spacing:.04em;padding:.4cqw .9cqw;border-radius:2cqw">${txt}</span>`;

  if (p.tipo === 'aniv') {
    const itens = p.itens.map(x => Object.assign({}, x, { data: typeof x.data === 'string' ? new Date(x.data + 'T12:00:00') : new Date(x.data) }));
    const cartao = x => {
      const hoje = x.diff === 0;
      const foto = x.m.foto
        ? `<div style="height:100%;background:#d9e4ec ${urlCss(x.m.foto)} center / cover no-repeat"></div>`
        : `<div style="height:100%;background:#d9e4ec;display:flex;align-items:center;justify-content:center;color:#1B4D3A;font-size:6cqw;font-weight:800">${escH(String(x.m.nome).trim().charAt(0).toUpperCase())}</div>`;
      return `<div style="position:relative;width:21.5cqw;height:54cqh;flex:none;border-radius:1.2cqw;overflow:hidden;background:#173a2c;border:.16cqw solid ${hoje ? '#E0B96A' : 'rgba(255,255,255,.12)'};display:flex;flex-direction:column">
        <div style="position:relative;height:58%">${foto}${hoje ? selo('É HOJE!') : ''}${x.m.casal ? `<span style="position:absolute;top:1cqw;right:1cqw;background:#f4f1ea;color:#1B4D3A;font-weight:700;font-size:.95cqw;padding:.35cqw .8cqw;border-radius:2cqw">CASAMENTO</span>` : ''}</div>
        <div style="flex:1;padding:1.3cqw 1.4cqw;display:flex;flex-direction:column;justify-content:space-between;min-height:0">
          <div style="font-weight:800;font-size:2.15cqw;line-height:1.12;letter-spacing:-.01em;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${escH(x.m.nome)}</div>
          <div style="color:#E0B96A;font-weight:800;font-size:1.45cqw;letter-spacing:.05em;text-transform:uppercase">${escH(I.rotuloData(x))}</div>
        </div></div>`;
    };
    return `<div style="${base}">${enfeites}${topo('Celebramos juntos • ' + I.periodo(), 'Aniversariantes da Semana', 'Que este novo ciclo seja repleto da presença, da graça e do amor de Deus.')}
      <div style="position:absolute;left:4cqw;right:4cqw;top:26cqh;display:flex;gap:1.6cqw;justify-content:flex-start;align-items:flex-start">${itens.map(cartao).join('')}</div>${pagina}${seguir}</div>`;
  }
  if (p.tipo === 'visit') {
    const hoje = new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
    const cartao = v => `<div style="position:relative;height:21cqh;border-radius:1.2cqw;background:#173a2c;border:.16cqw solid ${v.primeira ? '#E0B96A' : 'rgba(255,255,255,.12)'};padding:1.6cqw 1.8cqw;display:flex;flex-direction:column;justify-content:center">
        <div style="font-weight:800;font-size:2.3cqw;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escH(I.nomeVisitante(v))}${I.pessoas(v) > 1 ? `<span style="font-weight:600;color:#E0B96A"> · ${I.pessoas(v)}</span>` : ''}</div>
        <div style="font-size:1.5cqw;font-weight:500;color:#d8e6dd;margin-top:.5cqw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escH(I.descVisitante(v) || 'Seja bem-vindo(a)!')}</div>
        ${v.primeira ? `<div style="color:#E0B96A;font-weight:800;font-size:1.3cqw;letter-spacing:.08em;margin-top:.8cqw">1ª VISITA</div>` : ''}
      </div>`;
    return `<div style="${base}">${enfeites}${topo('Culto • ' + hoje, 'Sejam Bem-Vindos!', `Que alegria receber você. ${p.quantos} visitante${p.quantos > 1 ? 's' : ''} hoje.`)}
      <div style="position:absolute;left:4cqw;right:4cqw;top:27cqh;display:grid;grid-template-columns:repeat(3,1fr);gap:1.6cqw">${p.itens.map(cartao).join('')}</div>${pagina}${seguir}</div>`;
  }
  return '';
};
