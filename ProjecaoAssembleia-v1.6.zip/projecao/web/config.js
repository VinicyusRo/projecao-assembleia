// Preencha com os dados do seu projeto Supabase (Project Settings > API).
// A chave pública (anon / publishable) pode ficar aqui: a segurança é feita pelo login da equipe.
window.NUVEM = {
  url: '',    // ex.: 'https://abcdefgh.supabase.co'
  chave: ''   // ex.: 'sb_publishable_...' ou 'eyJhbGciOi...'
};
